"use strict";
// Crée le tout premier compte d'administration. À lancer UNE fois, depuis un ordinateur de confiance.
// Utilisation :
//   1. La personne crée d'abord son compte dans l'application, ou tu crées un utilisateur dans la console Firebase.
//   2. Console Firebase > Paramètres du projet > Comptes de service > générer une clé privée.
//      Garde ce fichier hors du dépôt. Ne le partage jamais.
//   3. GOOGLE_APPLICATION_CREDENTIALS=/chemin/cle.json node scripts/bootstrap-admin.js <uid> "Nom Complet" 0140810254
const { initializeApp } = require("firebase-admin/app");
const { getAuth } = require("firebase-admin/auth");
const { getFirestore, FieldValue } = require("firebase-admin/firestore");
const L = require("../src/logic");

const ALL = L.PERMISSIONS.slice();

async function main() {
  const [uid, nom, tel] = process.argv.slice(2);
  if (!uid || !nom) {
    console.error('Usage : node scripts/bootstrap-admin.js <uid> "Nom Complet" [telephone]');
    process.exit(1);
  }
  initializeApp();
  await getAuth().setCustomUserClaims(uid, { role: "admin", permissions: ALL });
  const doc = { role: "admin", nom, permissions: ALL, status: "active", valide: true, createdAt: FieldValue.serverTimestamp() };
  const phone = tel ? L.normalizePhone(tel) : null;
  if (tel && !phone) throw new Error("Numéro invalide.");
  if (phone) doc.tel = phone;
  await getFirestore().doc(`users/${uid}`).set(doc, { merge: true });
  await getAuth().revokeRefreshTokens(uid);
  console.log("Administrateur créé :", uid, "(toutes les fonctions). Il doit se reconnecter.");
}
main().catch((e) => { console.error(e.message); process.exit(1); });
