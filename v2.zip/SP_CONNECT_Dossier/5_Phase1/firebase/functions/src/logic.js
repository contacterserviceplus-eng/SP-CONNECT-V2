"use strict";
// Logique pure de SP CONNECT : aucune dépendance à Firebase. Elle est testée avec `npm test`.

const ROLES = ["eleve", "parent", "tuteur", "eleveprof", "prof", "ecole", "admin", "commercial", "compta"];
const SELF_REGISTER = ["eleve", "parent", "tuteur", "eleveprof", "prof", "ecole"];
const STAFF = ["admin", "commercial", "compta"];
const NEEDS_VALIDATION = ["tuteur", "eleveprof", "prof", "ecole"];
const CLASSES = ["CI", "CP", "CE1", "CE2", "CM1", "CM2", "6e", "5e", "4e", "3e", "Seconde", "Première", "Terminale"];
const SERIES = ["A1", "A2", "B", "C", "D", "E", "F1", "F2", "F3", "F4", "G1", "G2", "G3"];
const PERMISSIONS = ["accounts", "roles", "payments", "tarifs", "contents", "sessions", "journal"];
const RELATIONS = ["Oncle ou tante", "Grand-parent", "Frère ou sœur aîné(e)", "Autre membre de la famille", "Tuteur légal"];

function needsSerie(classe) {
  return classe === "Seconde" || classe === "Première" || classe === "Terminale";
}

// Numéro béninois à 10 chiffres commençant par 01, avec ou sans indicatif. Renvoie +229XXXXXXXXXX ou null.
function normalizePhone(raw) {
  if (typeof raw !== "string") return null;
  let s = raw.replace(/[\s.\-()]/g, "");
  if (s.startsWith("+229")) s = s.slice(4);
  else if (s.startsWith("00229")) s = s.slice(5);
  else if (s.startsWith("229") && s.length === 13) s = s.slice(3);
  return /^01\d{8}$/.test(s) ? "+229" + s : null;
}

function cleanText(value, min, max) {
  if (typeof value !== "string") return null;
  const s = value.replace(/\s+/g, " ").trim();
  return s.length >= min && s.length <= max ? s : null;
}

function validDate(iso, now) {
  if (typeof iso !== "string" || !/^\d{4}-\d{2}-\d{2}$/.test(iso)) return false;
  const [y, m, d] = iso.split("-").map(Number);
  const dt = new Date(Date.UTC(y, m - 1, d));
  if (dt.getUTCFullYear() !== y || dt.getUTCMonth() !== m - 1 || dt.getUTCDate() !== d) return false;
  return dt.getTime() <= now.getTime() && y >= 1950;
}

function cleanList(value, allowed, min, max) {
  if (!Array.isArray(value) || value.length < min || value.length > max) return null;
  const out = [];
  for (const item of value) {
    const s = typeof item === "string" ? item.replace(/\s+/g, " ").trim() : "";
    if (!s || s.length > 60) return null;
    if (allowed && !allowed.includes(s)) return null;
    if (!out.includes(s)) out.push(s);
  }
  return out;
}

// Vérifie les données d'inscription et ne garde que les champs autorisés (jamais status, role d'administration, etc.).
function validateRegistration(data, now = new Date()) {
  const errors = [];
  const clean = {};
  const d = data && typeof data === "object" ? data : {};
  const role = d.role;
  if (!SELF_REGISTER.includes(role)) {
    return { ok: false, errors: ["Ce profil ne peut pas être créé depuis l'application."], clean: {} };
  }
  clean.role = role;

  const nom = cleanText(d.nom, 3, 80);
  if (!nom) errors.push("Le nom et les prénoms doivent contenir entre 3 et 80 caractères.");
  else clean.nom = nom;

  if (role === "eleve") {
    if (!validDate(d.naissance, now)) errors.push("La date de naissance est invalide.");
    else clean.naissance = d.naissance;
    const etab = cleanText(d.etab, 2, 100);
    if (!etab) errors.push("L'établissement est obligatoire.");
    else clean.etab = etab;
    if (!CLASSES.includes(d.classe)) errors.push("La classe est invalide.");
    else {
      clean.classe = d.classe;
      if (needsSerie(d.classe)) {
        if (!SERIES.includes(d.serie)) errors.push("La série est obligatoire pour cette classe.");
        else clean.serie = d.serie;
      } else clean.serie = "";
    }
    const pn = cleanText(d.parentNom, 3, 80);
    const pt = normalizePhone(d.parentTel);
    if (!pn) errors.push("Le nom du parent responsable est obligatoire.");
    else clean.parentNom = pn;
    if (!pt) errors.push("Le téléphone du parent est invalide (10 chiffres, commençant par 01).");
    else clean.parentTel = pt;
  } else if (role === "parent") {
    if (d.email !== undefined && d.email !== "") {
      if (typeof d.email !== "string" || d.email.length > 120 || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(d.email)) errors.push("L'adresse e-mail est invalide.");
      else clean.email = d.email.trim().toLowerCase();
    }
  } else if (role === "tuteur") {
    if (!RELATIONS.includes(d.relation)) errors.push("La relation avec l'élève est invalide.");
    else clean.relation = d.relation;
    const en = cleanText(d.eleveNom, 3, 80);
    if (!en) errors.push("Le nom de l'élève associé est obligatoire.");
    else clean.eleveNom = en;
  } else if (role === "eleveprof" || role === "prof") {
    const m = cleanList(d.matieres, null, 1, 10);
    if (!m) errors.push("Indique de 1 à 10 matières.");
    else clean.matieres = m;
    const c = cleanList(d.classes, CLASSES, 1, CLASSES.length);
    if (!c) errors.push("Les classes demandées sont invalides.");
    else clean.classes = c;
  } else if (role === "ecole") {
    const en = cleanText(d.ecoleNom, 2, 100);
    const v = cleanText(d.ville, 2, 60);
    const r = cleanText(d.resp, 3, 80);
    if (!en) errors.push("Le nom de l'établissement est obligatoire.");
    else clean.ecoleNom = en;
    if (!v) errors.push("La ville est obligatoire.");
    else clean.ville = v;
    if (!r) errors.push("Le nom du responsable est obligatoire.");
    else clean.resp = r;
  }
  return { ok: errors.length === 0, errors, clean };
}

function statusForNewAccount(role) {
  return NEEDS_VALIDATION.includes(role) ? "pending" : "active";
}

// Changements de statut par l'administration. Lève une erreur si l'action n'est pas permise.
function applyAction(account, action) {
  const { status, role } = account;
  const valide = !!account.valide;
  if (action === "validate") {
    if (!NEEDS_VALIDATION.includes(role)) throw new Error("Ce profil n'a pas besoin de validation.");
    if (status !== "pending") throw new Error("Seul un compte en attente peut être validé.");
    return { status: "active", valide: true };
  }
  if (action === "suspend") {
    if (status === "suspended") throw new Error("Le compte est déjà suspendu.");
    return { status: "suspended", valide };
  }
  if (action === "reactivate") {
    if (status !== "suspended") throw new Error("Seul un compte suspendu peut être réactivé.");
    const needs = NEEDS_VALIDATION.includes(role) && !valide;
    return { status: needs ? "pending" : "active", valide };
  }
  throw new Error("Action inconnue.");
}

function hasPermission(claims, permission) {
  return !!claims && claims.role === "admin" && Array.isArray(claims.permissions) && claims.permissions.includes(permission);
}

// Création ou changement d'un compte du personnel. L'administration ne limite les droits que pour le rôle admin.
function validateStaffAssignment(input) {
  const errors = [];
  const d = input && typeof input === "object" ? input : {};
  if (!STAFF.includes(d.role)) errors.push("Le rôle doit être admin, commercial ou compta.");
  let permissions = [];
  if (d.role === "admin") {
    if (!Array.isArray(d.permissions) || d.permissions.length === 0) errors.push("Indique au moins une fonction pour un compte d'administration.");
    else if (!d.permissions.every((p) => PERMISSIONS.includes(p))) errors.push("Une fonction demandée n'existe pas.");
    else permissions = Array.from(new Set(d.permissions));
  }
  return { ok: errors.length === 0, errors, role: d.role, permissions };
}

// Tous les abonnements expirent le 1er août. À confirmer : heure exacte et traitement du 1er août lui-même.
function nextExpiry(now = new Date()) {
  const y = now.getUTCFullYear();
  const thisYear = Date.UTC(y, 7, 1);
  return new Date(now.getTime() < thisYear ? thisYear : Date.UTC(y + 1, 7, 1));
}

function validDeviceId(id) {
  return typeof id === "string" && /^[A-Za-z0-9\-_]{8,64}$/.test(id);
}

module.exports = {
  ROLES, SELF_REGISTER, STAFF, NEEDS_VALIDATION, CLASSES, SERIES, PERMISSIONS, RELATIONS,
  needsSerie, normalizePhone, cleanText, validDate, validateRegistration, statusForNewAccount,
  applyAction, hasPermission, validateStaffAssignment, nextExpiry, validDeviceId,
};
