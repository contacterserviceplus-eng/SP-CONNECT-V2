"use strict";
const test = require("node:test");
const assert = require("node:assert/strict");
const L = require("../src/logic");

const NOW = new Date(Date.UTC(2026, 10, 13));

test("normalizePhone accepte les formes courantes et refuse le reste", () => {
  assert.equal(L.normalizePhone("01 97 20 70 69"), "+2290197207069");
  assert.equal(L.normalizePhone("0140810254"), "+2290140810254");
  assert.equal(L.normalizePhone("+229 01 63 94 00 13"), "+2290163940013");
  assert.equal(L.normalizePhone("00229 0163940013"), "+2290163940013");
  assert.equal(L.normalizePhone("2290163940013"), "+2290163940013");
  assert.equal(L.normalizePhone("97207069"), null);       // ancien format à 8 chiffres
  assert.equal(L.normalizePhone("0297207069"), null);     // ne commence pas par 01
  assert.equal(L.normalizePhone("01972070699"), null);    // trop long
  assert.equal(L.normalizePhone(null), null);
});

const eleveOk = { role: "eleve", nom: "Kossi  Adjovi", naissance: "2010-05-05", etab: "CEG Test", classe: "Terminale", serie: "B", parentNom: "Parent Test", parentTel: "01 40 81 02 54" };

test("inscription élève valide : champs nettoyés", () => {
  const r = L.validateRegistration(eleveOk, NOW);
  assert.equal(r.ok, true, r.errors.join(" "));
  assert.equal(r.clean.nom, "Kossi Adjovi");
  assert.equal(r.clean.parentTel, "+2290140810254");
  assert.equal(r.clean.serie, "B");
});

test("inscription élève : série obligatoire en Terminale, ignorée en 3e", () => {
  assert.equal(L.validateRegistration({ ...eleveOk, serie: undefined }, NOW).ok, false);
  const r = L.validateRegistration({ ...eleveOk, classe: "3e", serie: "C" }, NOW);
  assert.equal(r.ok, true);
  assert.equal(r.clean.serie, "");
});

test("inscription : dates invalides refusées", () => {
  assert.equal(L.validateRegistration({ ...eleveOk, naissance: "2031-01-01" }, NOW).ok, false);
  assert.equal(L.validateRegistration({ ...eleveOk, naissance: "2010-02-30" }, NOW).ok, false);
  assert.equal(L.validateRegistration({ ...eleveOk, naissance: "05/05/2010" }, NOW).ok, false);
});

test("inscription : un profil du personnel ou inconnu est refusé", () => {
  for (const role of ["admin", "commercial", "compta", "root", undefined]) {
    assert.equal(L.validateRegistration({ role, nom: "Test Test" }, NOW).ok, false, String(role));
  }
});

test("inscription : les champs non autorisés ne passent pas", () => {
  const r = L.validateRegistration({ role: "parent", nom: "Parent Test", status: "active", permissions: ["accounts"], valide: true }, NOW);
  assert.equal(r.ok, true);
  assert.deepEqual(Object.keys(r.clean).sort(), ["nom", "role"]);
});

test("inscription enseignant et école", () => {
  const p = L.validateRegistration({ role: "prof", nom: "Prof Test", matieres: ["Maths", "Maths", "PCT"], classes: ["3e", "Terminale"] }, NOW);
  assert.equal(p.ok, true);
  assert.deepEqual(p.clean.matieres, ["Maths", "PCT"]);
  assert.equal(L.validateRegistration({ role: "prof", nom: "Prof Test", matieres: [], classes: ["3e"] }, NOW).ok, false);
  assert.equal(L.validateRegistration({ role: "prof", nom: "Prof Test", matieres: ["Maths"], classes: ["9e"] }, NOW).ok, false);
  assert.equal(L.validateRegistration({ role: "ecole", nom: "Dir Test", ecoleNom: "Collège X", ville: "Cotonou", resp: "Dir Test" }, NOW).ok, true);
});

test("statut initial selon le profil", () => {
  assert.equal(L.statusForNewAccount("eleve"), "active");
  assert.equal(L.statusForNewAccount("parent"), "active");
  for (const r of ["tuteur", "eleveprof", "prof", "ecole"]) assert.equal(L.statusForNewAccount(r), "pending");
});

test("actions d'administration sur les statuts", () => {
  assert.deepEqual(L.applyAction({ role: "prof", status: "pending" }, "validate"), { status: "active", valide: true });
  assert.throws(() => L.applyAction({ role: "eleve", status: "active" }, "validate"));
  assert.throws(() => L.applyAction({ role: "prof", status: "active", valide: true }, "validate"));
  assert.deepEqual(L.applyAction({ role: "eleve", status: "active" }, "suspend"), { status: "suspended", valide: false });
  assert.throws(() => L.applyAction({ role: "eleve", status: "suspended" }, "suspend"));
  assert.equal(L.applyAction({ role: "eleve", status: "suspended" }, "reactivate").status, "active");
  // un enseignant suspendu avant sa validation revient en attente, pas actif
  assert.equal(L.applyAction({ role: "prof", status: "suspended", valide: false }, "reactivate").status, "pending");
  assert.equal(L.applyAction({ role: "prof", status: "suspended", valide: true }, "reactivate").status, "active");
  assert.throws(() => L.applyAction({ role: "eleve", status: "active" }, "reactivate"));
  assert.throws(() => L.applyAction({ role: "eleve", status: "active" }, "delete"));
});

test("droits d'administration limités par fonction", () => {
  const claims = { role: "admin", permissions: ["accounts"] };
  assert.equal(L.hasPermission(claims, "accounts"), true);
  assert.equal(L.hasPermission(claims, "payments"), false);
  assert.equal(L.hasPermission({ role: "compta", permissions: ["accounts"] }, "accounts"), false);
  assert.equal(L.hasPermission({ role: "admin" }, "accounts"), false);
  assert.equal(L.hasPermission(null, "accounts"), false);
});

test("attribution des rôles du personnel", () => {
  assert.equal(L.validateStaffAssignment({ role: "admin", permissions: ["accounts", "journal", "accounts"] }).ok, true);
  assert.deepEqual(L.validateStaffAssignment({ role: "admin", permissions: ["accounts", "accounts"] }).permissions, ["accounts"]);
  assert.equal(L.validateStaffAssignment({ role: "admin", permissions: [] }).ok, false);
  assert.equal(L.validateStaffAssignment({ role: "admin", permissions: ["tout"] }).ok, false);
  assert.equal(L.validateStaffAssignment({ role: "eleve", permissions: [] }).ok, false);
  assert.deepEqual(L.validateStaffAssignment({ role: "compta", permissions: ["accounts"] }).permissions, []);
});

test("expiration des abonnements au 1er août", () => {
  assert.equal(L.nextExpiry(new Date(Date.UTC(2026, 10, 13))).toISOString(), "2027-08-01T00:00:00.000Z");
  assert.equal(L.nextExpiry(new Date(Date.UTC(2026, 2, 1))).toISOString(), "2026-08-01T00:00:00.000Z");
  assert.equal(L.nextExpiry(new Date(Date.UTC(2026, 7, 1))).toISOString(), "2027-08-01T00:00:00.000Z");
  assert.equal(L.nextExpiry(new Date(Date.UTC(2026, 6, 31, 23, 59))).toISOString(), "2026-08-01T00:00:00.000Z");
});

test("identifiant d'appareil", () => {
  assert.equal(L.validDeviceId("a1b2c3d4-e5f6-7890"), true);
  assert.equal(L.validDeviceId("court"), false);
  assert.equal(L.validDeviceId("a b c d e f g h"), false);
  assert.equal(L.validDeviceId(12345678), false);
});
