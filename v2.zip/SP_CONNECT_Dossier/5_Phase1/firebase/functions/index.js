"use strict";
// Fonctions serveur de SP CONNECT, Phase 1. Non déployées ni testées sur un vrai projet Firebase.
// La logique pure est dans src/logic.js et testée avec `npm test`.

const { onCall, HttpsError } = require("firebase-functions/v2/https");
const { setGlobalOptions } = require("firebase-functions/v2");
const { initializeApp } = require("firebase-admin/app");
const { getAuth } = require("firebase-admin/auth");
const { getFirestore, FieldValue, Timestamp } = require("firebase-admin/firestore");
const L = require("./src/logic");

setGlobalOptions({ region: "europe-west1", maxInstances: 10 });
initializeApp();
const db = getFirestore();

const LOG_RETENTION_DAYS = 180; // conservation envisagée : six mois (cahier des charges, section 18)

function requireAuth(req) {
  if (!req.auth) throw new HttpsError("unauthenticated", "Connexion requise.");
  return req.auth;
}

// Vérifie le rôle dans le jeton ET le statut réel dans la base.
async function requireStaff(req, permission) {
  const auth = requireAuth(req);
  if (!L.hasPermission(auth.token, permission)) throw new HttpsError("permission-denied", "Droit insuffisant.");
  const snap = await db.doc(`users/${auth.uid}`).get();
  if (!snap.exists || snap.data().status !== "active") throw new HttpsError("permission-denied", "Compte non actif.");
  return auth;
}

async function writeAdminLog(by, action, target, details) {
  await db.collection("adminLog").add({ by, action, target, details: details || {}, at: FieldValue.serverTimestamp() });
}

// 1) Création du profil après vérification du numéro par SMS (le jeton contient alors phone_number).
exports.registerProfile = onCall(async (req) => {
  const auth = requireAuth(req);
  const phone = auth.token.phone_number;
  if (!phone) throw new HttpsError("failed-precondition", "Le numéro de téléphone n'est pas vérifié.");

  const v = L.validateRegistration(req.data);
  if (!v.ok) throw new HttpsError("invalid-argument", v.errors.join(" "));

  const status = L.statusForNewAccount(v.clean.role);
  const ref = db.doc(`users/${auth.uid}`);
  await db.runTransaction(async (tx) => {
    const existing = await tx.get(ref);
    if (existing.exists) throw new HttpsError("already-exists", "Un profil existe déjà pour ce compte.");
    tx.set(ref, { ...v.clean, tel: phone, status, valide: status === "active", createdAt: FieldValue.serverTimestamp() });
  });
  await getAuth().setCustomUserClaims(auth.uid, { role: v.clean.role, permissions: [] });
  return { role: v.clean.role, status };
});

// 2) Un seul téléphone actif : la dernière connexion remplace la précédente.
exports.claimSession = onCall(async (req) => {
  const auth = requireAuth(req);
  const { deviceId, deviceName } = req.data || {};
  if (!L.validDeviceId(deviceId)) throw new HttpsError("invalid-argument", "Identifiant d'appareil invalide.");
  const name = L.cleanText(String(deviceName || ""), 1, 60) || "Appareil inconnu";

  const ref = db.doc(`users/${auth.uid}`);
  const snap = await ref.get();
  if (!snap.exists) throw new HttpsError("failed-precondition", "Profil introuvable.");
  if (snap.data().status === "suspended") throw new HttpsError("permission-denied", "Ce compte est suspendu.");

  const expireAt = Timestamp.fromMillis(Date.now() + LOG_RETENTION_DAYS * 24 * 3600 * 1000);
  const batch = db.batch();
  batch.update(ref, { activeDeviceId: deviceId, activeDeviceName: name, activeDeviceAt: FieldValue.serverTimestamp() });
  batch.set(db.collection("connectionLogs").doc(), { uid: auth.uid, deviceId, deviceName: name, at: FieldValue.serverTimestamp(), expireAt });
  await batch.commit();
  return { ok: true };
});

// 3) Validation, suspension et réactivation d'un compte par l'administration.
exports.adminSetStatus = onCall(async (req) => {
  const admin = await requireStaff(req, "accounts");
  const { uid, action } = req.data || {};
  if (typeof uid !== "string" || !uid) throw new HttpsError("invalid-argument", "Compte manquant.");
  if (uid === admin.uid) throw new HttpsError("failed-precondition", "Tu ne peux pas modifier ton propre compte.");

  const ref = db.doc(`users/${uid}`);
  const result = await db.runTransaction(async (tx) => {
    const snap = await tx.get(ref);
    if (!snap.exists) throw new HttpsError("not-found", "Compte introuvable.");
    let next;
    try {
      next = L.applyAction({ role: snap.data().role, status: snap.data().status, valide: snap.data().valide }, action);
    } catch (e) {
      throw new HttpsError("failed-precondition", e.message);
    }
    tx.update(ref, { status: next.status, valide: next.valide, statusChangedAt: FieldValue.serverTimestamp(), statusChangedBy: admin.uid });
    return next;
  });
  if (action === "suspend") await getAuth().revokeRefreshTokens(uid);
  await writeAdminLog(admin.uid, "status:" + action, uid, result);
  return result;
});

// 4) Attribution d'un rôle du personnel (admin, commercial, compta) avec les fonctions autorisées.
exports.adminSetRole = onCall(async (req) => {
  const admin = await requireStaff(req, "roles");
  const { uid } = req.data || {};
  if (typeof uid !== "string" || !uid) throw new HttpsError("invalid-argument", "Compte manquant.");
  if (uid === admin.uid) throw new HttpsError("failed-precondition", "Tu ne peux pas modifier ton propre rôle.");
  const v = L.validateStaffAssignment(req.data);
  if (!v.ok) throw new HttpsError("invalid-argument", v.errors.join(" "));

  const ref = db.doc(`users/${uid}`);
  const snap = await ref.get();
  if (!snap.exists) throw new HttpsError("not-found", "Compte introuvable : la personne doit d'abord créer son compte.");
  await ref.update({ role: v.role, permissions: v.permissions, status: "active", valide: true });
  await getAuth().setCustomUserClaims(uid, { role: v.role, permissions: v.permissions });
  await getAuth().revokeRefreshTokens(uid);
  await writeAdminLog(admin.uid, "role", uid, { role: v.role, permissions: v.permissions });
  return { role: v.role, permissions: v.permissions };
});
