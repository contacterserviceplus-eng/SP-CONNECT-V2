# Intégration dans le projet Android

Ces fichiers Kotlin ne sont PAS dans le projet `SP_CONNECT_Android` actuel, pour ne pas casser sa compilation.
Ils n'ont pas été compilés. Un développeur Android doit les intégrer, les compiler et les tester.

## Ordre
1. Créer le projet Firebase et télécharger `google-services.json` dans le dossier `app/` (voir le README de la Phase 1). Ne jamais le publier.
2. Copier les fichiers de `src/` dans `app/src/main/java/com/spconnect/application/` (sous-dossiers `core`, `auth`, `session`, `util`, en respectant les `package`).
3. Modifier les fichiers Gradle comme ci-dessous.

## build.gradle.kts (racine), bloc plugins
```kotlin
id("com.google.gms.google-services") version "4.4.2" apply false
```

## app/build.gradle.kts
```kotlin
plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("com.google.gms.google-services")
}

dependencies {
    implementation(platform("com.google.firebase:firebase-bom:33.1.2"))
    implementation("com.google.firebase:firebase-auth-ktx")
    implementation("com.google.firebase:firebase-firestore-ktx")
    implementation("com.google.firebase:firebase-functions-ktx")
    implementation("com.google.firebase:firebase-appcheck-playintegrity")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-play-services:1.8.1")
}
```
Les numéros de version sont indicatifs : prendre les dernières versions stables dans Android Studio.

## Sécurité à activer (App Check)
Dans une classe `Application` :
```kotlin
FirebaseApp.initializeApp(this)
FirebaseAppCheck.getInstance().installAppCheckProviderFactory(PlayIntegrityAppCheckProviderFactory.getInstance())
```
Puis, dans la console Firebase, activer App Check pour Authentication, Firestore et Functions.
Cela limite l'accès au serveur aux installations authentiques de l'application.

## Écrans à créer (non faits)
Accueil, choix du profil, inscription (champs selon le profil), saisie du code SMS, connexion, mot de passe oublié,
écran « en attente de validation », écran « compte suspendu », déconnexion. `homeFor(profile)` donne l'écran d'arrivée.
