package com.spconnect.application.auth

import android.app.Activity
import com.google.firebase.auth.EmailAuthProvider
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.PhoneAuthCredential
import com.google.firebase.auth.PhoneAuthOptions
import com.google.firebase.auth.PhoneAuthProvider
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.functions.FirebaseFunctions
import com.spconnect.application.core.AccountStatus
import com.spconnect.application.core.Role
import com.spconnect.application.core.UserProfile
import kotlinx.coroutines.tasks.await
import java.util.concurrent.TimeUnit

data class RegisterResult(val role: Role?, val status: AccountStatus)

/**
 * Connexion par numéro de téléphone et mot de passe.
 * - Le numéro est vérifié par SMS à l'inscription et au mot de passe oublié.
 * - Le mot de passe est stocké par Firebase sous la forme d'un e-mail technique dérivé du numéro.
 *   Cet e-mail n'est jamais affiché ni utilisé pour écrire à la personne.
 * - Le profil et le rôle sont créés par le serveur (fonction registerProfile), jamais par l'application.
 */
class AuthRepository(
    private val auth: FirebaseAuth = FirebaseAuth.getInstance(),
    private val functions: FirebaseFunctions = FirebaseFunctions.getInstance("europe-west1"),
    private val db: FirebaseFirestore = FirebaseFirestore.getInstance()
) {
    private fun pseudoEmail(phoneE164: String) = phoneE164.removePrefix("+") + "@users.spconnect.app"

    fun startPhoneVerification(
        activity: Activity,
        phoneE164: String,
        callbacks: PhoneAuthProvider.OnVerificationStateChangedCallbacks
    ) {
        val options = PhoneAuthOptions.newBuilder(auth)
            .setPhoneNumber(phoneE164)
            .setTimeout(60L, TimeUnit.SECONDS)
            .setActivity(activity)
            .setCallbacks(callbacks)
            .build()
        PhoneAuthProvider.verifyPhoneNumber(options)
    }

    fun credentialFromCode(verificationId: String, code: String): PhoneAuthCredential =
        PhoneAuthProvider.getCredential(verificationId, code)

    /** Inscription : numéro vérifié, mot de passe lié, puis profil créé par le serveur. */
    suspend fun register(
        phoneCredential: PhoneAuthCredential,
        phoneE164: String,
        password: String,
        profile: Map<String, Any?>
    ): RegisterResult {
        val user = auth.signInWithCredential(phoneCredential).await().user
            ?: throw IllegalStateException("Utilisateur introuvable après la vérification.")
        user.linkWithCredential(EmailAuthProvider.getCredential(pseudoEmail(phoneE164), password)).await()
        user.getIdToken(true).await() // le jeton doit contenir phone_number
        val data = functions.getHttpsCallable("registerProfile").call(profile).await().data as? Map<*, *>
            ?: throw IllegalStateException("Réponse du serveur invalide.")
        user.getIdToken(true).await() // jeton rafraîchi avec le rôle
        return RegisterResult(Role.fromId(data["role"] as? String), AccountStatus.fromId(data["status"] as? String))
    }

    suspend fun signIn(phoneE164: String, password: String) {
        auth.signInWithEmailAndPassword(pseudoEmail(phoneE164), password).await()
    }

    /** Mot de passe oublié : le numéro vérifié par SMS ouvre le même compte, puis on change le mot de passe. */
    suspend fun resetPassword(phoneCredential: PhoneAuthCredential, newPassword: String) {
        val user = auth.signInWithCredential(phoneCredential).await().user
            ?: throw IllegalStateException("Utilisateur introuvable après la vérification.")
        user.updatePassword(newPassword).await()
    }

    /**
     * Renvoie null si le profil n'existe pas : l'inscription a été interrompue après la vérification du numéro.
     * L'écran doit alors proposer de terminer l'inscription (appel de registerProfile).
     */
    suspend fun loadProfile(): UserProfile? {
        val uid = auth.currentUser?.uid ?: return null
        return UserProfile.from(db.collection("users").document(uid).get().await())
    }

    fun signOut() = auth.signOut()
}
