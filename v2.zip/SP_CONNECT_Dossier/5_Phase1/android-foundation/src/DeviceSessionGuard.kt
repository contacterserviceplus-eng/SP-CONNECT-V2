package com.spconnect.application.session

import android.content.Context
import android.os.Build
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ListenerRegistration
import com.google.firebase.functions.FirebaseFunctions
import com.spconnect.application.core.AccountStatus
import com.spconnect.application.core.UserProfile
import kotlinx.coroutines.tasks.await
import java.util.UUID

enum class EndReason { SUSPENDED, OTHER_DEVICE }

/**
 * Un compte actif ne peut servir que sur un seul téléphone à la fois.
 * Ordre à respecter : claim() après la connexion, puis watch(). Dans l'ordre inverse, l'application
 * verrait l'ancien appareil dans le profil et se déconnecterait aussitôt.
 */
class DeviceSessionGuard(
    context: Context,
    private val auth: FirebaseAuth = FirebaseAuth.getInstance(),
    private val db: FirebaseFirestore = FirebaseFirestore.getInstance(),
    private val functions: FirebaseFunctions = FirebaseFunctions.getInstance("europe-west1")
) {
    private val prefs = context.applicationContext.getSharedPreferences("sp_device", Context.MODE_PRIVATE)

    /** Identifiant propre à cette installation (pas l'identifiant matériel du téléphone). */
    fun deviceId(): String =
        prefs.getString("id", null) ?: UUID.randomUUID().toString().also { prefs.edit().putString("id", it).apply() }

    suspend fun claim() {
        val payload = mapOf("deviceId" to deviceId(), "deviceName" to "${Build.MANUFACTURER} ${Build.MODEL}")
        functions.getHttpsCallable("claimSession").call(payload).await()
    }

    /** À appeler après claim(). Garde la référence renvoyée et appelle remove() à la déconnexion. */
    fun watch(onEnded: (EndReason) -> Unit): ListenerRegistration? {
        val uid = auth.currentUser?.uid ?: return null
        return db.collection("users").document(uid).addSnapshotListener { snap, error ->
            if (error != null || snap == null || !snap.exists() || snap.metadata.isFromCache) return@addSnapshotListener
            val profile = UserProfile.from(snap) ?: return@addSnapshotListener
            val reason = when {
                profile.status == AccountStatus.SUSPENDED -> EndReason.SUSPENDED
                profile.activeDeviceId != null && profile.activeDeviceId != deviceId() -> EndReason.OTHER_DEVICE
                else -> null
            }
            if (reason != null) {
                auth.signOut()
                onEnded(reason)
            }
        }
    }
}
