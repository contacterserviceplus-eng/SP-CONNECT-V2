package com.spconnect.application.core

// Profils de SP CONNECT. Les identifiants doivent rester identiques à ceux du serveur (firebase/functions/src/logic.js).
enum class Role(val id: String, val label: String, val selfRegister: Boolean, val needsValidation: Boolean) {
    ELEVE("eleve", "Élève", true, false),
    PARENT("parent", "Parent", true, false),
    TUTEUR("tuteur", "Tuteur", true, true),
    ELEVE_PROF("eleveprof", "Élève-professeur", true, true),
    PROF("prof", "Professeur titulaire ou tuteur", true, true),
    ECOLE("ecole", "École partenaire", true, true),
    ADMIN("admin", "Administration", false, false),
    COMMERCIAL("commercial", "Commercial", false, false),
    COMPTA("compta", "Comptabilité", false, false);

    companion object {
        fun fromId(id: String?): Role? = values().firstOrNull { it.id == id }
    }
}

enum class AccountStatus(val id: String) {
    PENDING("pending"),
    ACTIVE("active"),
    SUSPENDED("suspended");

    companion object {
        // Un statut inconnu est traité comme « en attente » : le moins de droits possible.
        fun fromId(id: String?): AccountStatus = values().firstOrNull { it.id == id } ?: PENDING
    }
}

enum class Destination {
    SUSPENDED, PENDING_VALIDATION,
    STUDENT_HOME, PARENT_HOME, TUTOR_HOME, TEACHER_HOME, SCHOOL_HOME,
    ADMIN_HOME, COMMERCIAL_HOME, ACCOUNTING_HOME
}

// Chaque utilisateur n'arrive que sur l'écran de son profil. Le serveur et les règles Firestore font la vraie vérification.
fun homeFor(profile: UserProfile): Destination = when (profile.status) {
    AccountStatus.SUSPENDED -> Destination.SUSPENDED
    AccountStatus.PENDING -> Destination.PENDING_VALIDATION
    AccountStatus.ACTIVE -> when (profile.role) {
        Role.ELEVE -> Destination.STUDENT_HOME
        Role.PARENT -> Destination.PARENT_HOME
        Role.TUTEUR -> Destination.TUTOR_HOME
        Role.ELEVE_PROF, Role.PROF -> Destination.TEACHER_HOME
        Role.ECOLE -> Destination.SCHOOL_HOME
        Role.ADMIN -> Destination.ADMIN_HOME
        Role.COMMERCIAL -> Destination.COMMERCIAL_HOME
        Role.COMPTA -> Destination.ACCOUNTING_HOME
    }
}
