package com.spconnect.application.core

import com.google.firebase.firestore.DocumentSnapshot

data class UserProfile(
    val uid: String,
    val role: Role,
    val status: AccountStatus,
    val nom: String,
    val tel: String?,
    val activeDeviceId: String?
) {
    companion object {
        fun from(doc: DocumentSnapshot): UserProfile? {
            if (!doc.exists()) return null
            val role = Role.fromId(doc.getString("role")) ?: return null
            return UserProfile(
                uid = doc.id,
                role = role,
                status = AccountStatus.fromId(doc.getString("status")),
                nom = doc.getString("nom") ?: "",
                tel = doc.getString("tel"),
                activeDeviceId = doc.getString("activeDeviceId")
            )
        }
    }
}
