package com.spconnect.application.util

import com.google.firebase.FirebaseNetworkException
import com.google.firebase.FirebaseTooManyRequestsException
import com.google.firebase.auth.FirebaseAuthInvalidCredentialsException
import com.google.firebase.auth.FirebaseAuthInvalidUserException
import com.google.firebase.auth.FirebaseAuthUserCollisionException
import com.google.firebase.functions.FirebaseFunctionsException

/** Transforme une erreur technique en phrase que l'utilisateur peut comprendre et agir dessus. */
object ErrorMapper {
    fun message(e: Throwable): String = when (e) {
        is FirebaseNetworkException -> "Pas de connexion internet. Vérifie ton réseau et réessaie."
        is FirebaseTooManyRequestsException -> "Trop de tentatives. Réessaie dans quelques minutes."
        is FirebaseAuthInvalidUserException -> "Aucun compte avec ce numéro."
        is FirebaseAuthInvalidCredentialsException -> "Numéro, code ou mot de passe incorrect."
        is FirebaseAuthUserCollisionException -> "Un compte existe déjà avec ce numéro. Connecte-toi."
        is FirebaseFunctionsException -> when (e.code) {
            // Ces messages sont écrits en français par le serveur.
            FirebaseFunctionsException.Code.INVALID_ARGUMENT,
            FirebaseFunctionsException.Code.FAILED_PRECONDITION,
            FirebaseFunctionsException.Code.ALREADY_EXISTS,
            FirebaseFunctionsException.Code.PERMISSION_DENIED -> e.message ?: "Action refusée."
            FirebaseFunctionsException.Code.UNAUTHENTICATED -> "Ta session a expiré. Reconnecte-toi."
            FirebaseFunctionsException.Code.UNAVAILABLE,
            FirebaseFunctionsException.Code.DEADLINE_EXCEEDED -> "Le serveur ne répond pas. Réessaie dans un instant."
            else -> "Une erreur est survenue. Réessaie."
        }
        else -> "Une erreur est survenue. Réessaie."
    }
}
