# SP CONNECT — Phase 1 : architecture

Statut : **Rédigé** (rien n'est déployé, rien n'est testé sur un vrai projet Firebase).

## 1. Choix
- Android (WebView pour la maquette actuelle ; écrans natifs à créer pour la Phase 1 réelle).
- Firebase : Authentication (SMS + e-mail technique/mot de passe), Firestore, Cloud Functions v2 (Node 20, europe-west1).
- Le client ne crée ni rôle, ni statut, ni journal. Tout passe par des fonctions serveur.

## 2. Données
| Collection | Contenu | Lecture | Écriture |
|---|---|---|---|
| users/{uid} | role, status (pending/active/suspended), nom, tel, activeDeviceId, champs du profil | le propriétaire ; staff avec permission `accounts` | serveur uniquement |
| connectionLogs/{id} | uid, deviceId, deviceName, at, expireAt | le propriétaire ; staff | serveur uniquement |
| adminLog/{id} | by, action, target, details, at | staff avec permission `journal` | serveur uniquement |
| tout le reste | — | refusé | refusé |

Purge : politique TTL Firestore sur `connectionLogs.expireAt` (6 mois). À activer à la main dans la console.

## 3. Rôles
- Inscription libre : eleve, parent (actifs tout de suite) ; tuteur, eleveprof, prof, ecole (en attente de validation par l'administration).
- Personnel (attribué par un admin) : admin, commercial, compta.
- Permissions admin : accounts, roles, payments, tarifs, contents, sessions, journal. Elles sont dans le jeton (custom claims) et le statut est revérifié en direct dans les règles.

## 4. Fonctions serveur
- registerProfile : valide la liste blanche des champs, impose le numéro vérifié du jeton, fixe rôle et statut.
- claimSession : enregistre l'appareil actif et écrit un journal de connexion.
- adminSetStatus : valider / suspendre / réactiver ; une suspension révoque les jetons.
- adminSetRole : attribue un rôle du personnel et ses permissions ; révoque les jetons.

## 5. Session
Un seul appareil actif par compte. Le client écoute users/{uid} et se déconnecte si le statut est « suspended » ou si activeDeviceId diffère. Ordre : claim() puis watch().

## 6. Sécurité
Règles Firestore strictes, Storage fermé, App Check à activer, clés (serviceAccount, google-services.json) jamais publiées, mot de passe oublié = nouveau code SMS.

## 7. Erreurs, journaux, sauvegarde
ErrorMapper traduit les erreurs en français. Sauvegardes Firestore planifiées : à configurer (non fait).

## 8. Décisions ouvertes
Date d'expiration des abonnements (1er août, fuseau à confirmer), fournisseur de paiement, durée de conservation des données, formules du cahier §25, offre Firebase (Blaze probablement requise pour Functions et SMS : à vérifier).
