# SP CONNECT — Phase 1 (fondations)

## Contenu
- firebase/ : règles Firestore, fonctions serveur, tests, script du premier admin
- android-foundation/ : sources Kotlin (NON compilées) + notes d'intégration
- docs/ARCHITECTURE.md

## Ce qui est vérifié
Seulement la logique pure : `cd firebase/functions && npm install && npm test` → 13 tests passent.

## Ce qui n'est PAS vérifié
Déploiement, règles sur un vrai projet, SMS, fonctions appelées depuis l'app, compilation Kotlin.

## Étapes pour toi
1. Console Firebase : créer le projet. Activer Authentication (Téléphone + E-mail/Mot de passe), Firestore.
2. Ajouter l'application Android `com.spconnect.application`, télécharger `google-services.json` dans `app/`. Ne jamais le publier.
3. `npm i -g firebase-tools`, `firebase login`, copier `.firebaserc.example` en `.firebaserc`.
4. `cd firebase/functions && npm install && npm test`
5. `firebase deploy --only firestore:rules,firestore:indexes,functions` (le forfait Blaze est probablement exigé : à vérifier).
6. Console : politique TTL sur `connectionLogs`, champ `expireAt`. Activer App Check. Planifier les sauvegardes.
7. Créer ton compte, puis : `GOOGLE_APPLICATION_CREDENTIALS=cle.json node scripts/bootstrap-admin.js <uid> "Nom" 0140810254` (clé de service gardée hors dépôt).
8. Intégrer le Kotlin avec android-foundation/GRADLE_ET_INTEGRATION.md.
