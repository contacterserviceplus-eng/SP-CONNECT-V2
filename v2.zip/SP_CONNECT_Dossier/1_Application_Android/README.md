# SP CONNECT (Android)

Package : `com.spconnect.application` · Version 0.1.0-demo

Ce projet est la coque Android de SP CONNECT. Il affiche la maquette interactive
(`app/src/main/assets/index.html`). C'est une démonstration : pas de vrais comptes,
pas de base de données, pas de paiement réel. Voir la feuille « État du projet » dans l'application.

## Générer l'APK de test
1. Installer Android Studio (version récente) sur un ordinateur.
2. Ouvrir ce dossier (File > Open). Android Studio télécharge Gradle et les outils, puis synchronise.
3. Brancher un téléphone Android (mode développeur activé) ou créer un émulateur, puis Run.
4. APK de test : Build > Build Bundle(s) / APK(s) > Build APK(s).
5. AAB de publication : Build > Generate Signed Bundle / APK, avec une clé que tu gardes toi seul.

## Règles du cahier des charges
- Ne jamais publier de clés secrètes ni de fichier `google-services.json` dans un dépôt public.
- Le code source et les accès restent sous le contrôle du propriétaire du projet.

## Prochaine étape (Phase 1)
Authentification, sessions, rôles, base de données (par exemple Firebase avec règles de sécurité),
puis remplacement progressif des écrans de démonstration par de vrais écrans natifs.
